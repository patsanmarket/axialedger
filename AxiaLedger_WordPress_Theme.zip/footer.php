
<footer style="background:#003B6D; color:white; text-align:center; padding:20px;">
  <p>© <?php echo date('Y'); ?> Axia Ledger. All rights reserved.</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
