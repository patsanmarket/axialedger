
<?php get_header(); ?>
<div id="content" class="site-content">
  <section class="hero" style="background: linear-gradient(to right, #003B6D, #00BCD4); color: white; padding: 40px; text-align: center;">
    <h1>Axia Ledger</h1>
    <p>Your trusted Indian partner for U.S. Accounting, Taxation, and Audit Services</p>
    <a href="#appointment" class="btn">Book a Free Consultation</a>
  </section>

  <section id="about" style="padding: 40px; background: #f9f9f9; text-align: center;">
    <h2>About Axia Ledger</h2>
    <p>Axia Ledger is a premier KPO firm based in India, offering U.S. Accounting, Taxation, and Audit services.</p>
  </section>

  <section id="services" style="padding: 40px; text-align: center;">
    <h2>Our Services</h2>
    <ul>
      <li>Accounting Services – Bookkeeping, Payroll, QuickBooks/Xero</li>
      <li>Taxation – U.S. Tax Filing (1040, 1120, 1065)</li>
      <li>Audit – SOX, Internal Audits, Due Diligence</li>
    </ul>
  </section>

  <section id="leadmagnet" style="padding: 40px; background: #F2FBFF; text-align: center;">
    <h2>Download: 2025 U.S. Tax Prep Checklist</h2>
    <p><a href="/wp-content/themes/axia-ledger-theme/US_Tax_Outsourcing_Checklist_AxiaLedger.pdf" class="btn">Download Now</a></p>
  </section>

  <section id="blog" style="padding: 40px; text-align: center;">
    <h2>Insights for U.S. CPAs & Firms</h2>
    <ul>
      <li><strong>How U.S. Firms Save 60% with Indian KPOs</strong></li>
      <li><strong>5 IRS-Compliant Outsourcing Practices</strong></li>
    </ul>
  </section>

  <section id="appointment" style="padding: 40px; background: #eee; text-align: center;">
    <h2>Schedule Your Free Consultation</h2>
    <iframe src="https://calendly.com/axialedger/consultation" width="100%" height="600" frameborder="0"></iframe>
  </section>
</div>
<?php get_footer(); ?>
